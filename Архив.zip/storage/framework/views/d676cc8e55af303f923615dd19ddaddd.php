<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Certificates']); ?>
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800">🏆 Certificates</h1>
        <a href="<?php echo e(route('certificate.create')); ?>"
           class="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-5 py-2.5 rounded-xl shadow hover:from-blue-600 hover:to-indigo-700 transition-all">
            + Add New
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 border border-green-300 p-3 rounded-lg mb-5 shadow-sm">
            ✅ <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="overflow-hidden rounded-lg shadow">
        <table class="min-w-full bg-white border border-gray-200">
            <thead class="bg-gray-50 border-b border-gray-200">
            <tr class="text-left text-gray-700 uppercase text-sm tracking-wider">
                <th class="py-3 px-4">Name</th>
                <th class="py-3 px-4">Role</th>
                <th class="py-3 px-4">Category</th>
                <th class="py-3 px-4">Photo</th>
                <th class="py-3 px-4 text-center">Actions</th>
            </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
            <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition-all">
                    <td class="py-3 px-4 font-medium text-gray-800">
                        <a href="<?php echo e(route('certificate.show', $certificate->id)); ?>"
                           class="text-blue-600 hover:underline">
                            <?php echo e($certificate->name); ?>

                        </a>
                    </td>

                    <td class="py-3 px-4">
                            <span class="px-3 py-1 rounded-full text-sm
                                <?php echo e($certificate->role->name == 'Talaba' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'); ?>">
                                <?php echo e($certificate->role->name); ?>

                            </span>
                    </td>

                    <td class="py-3 px-4">
                        <span class="text-gray-700"><?php echo e($certificate->category->name); ?></span>
                    </td>

                    <td class="py-3 px-4">
                        <img src="<?php echo e(url('storage/' . $certificate->photo)); ?>"
                             class="w-16 h-16 object-cover rounded-lg border border-gray-200 shadow-sm" />
                    </td>

                    <td class="py-3 px-4 text-center space-x-2">
                        <a href="<?php echo e(route('certificate.edit', $certificate)); ?>"
                           class="inline-block bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1.5 rounded-lg shadow text-sm transition">
                            Edit
                        </a>

                        <form action="<?php echo e(route('certificate.destroy', $certificate)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button
                                onclick="return confirm('Are you sure you want to delete this certificate?')"
                                class="bg-red-500 hover:bg-red-600 text-white px-3 py-1.5 rounded-lg shadow text-sm transition">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-gray-500 py-6">
                        No certificates found 😕
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH /Users/boburbek/Documents/projects/cert.local/resources/views/certificate/index.blade.php ENDPATH**/ ?>