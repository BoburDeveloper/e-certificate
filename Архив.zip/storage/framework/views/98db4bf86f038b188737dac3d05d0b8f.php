<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Certificate of Achievement']); ?>
    <button type="button" onclick="printDiv('document-card')"
            class="absolute top-4 right-4 bg-blue-600 text-white px-4 py-2 rounded shadow hover:bg-blue-700">
        PDF
    </button>

    <div class="flex justify-center items-center min-h-screen bg-gray-100 py-10">
        <div class="document-card relative w-[1100px] h-[750px] shadow-2xl overflow-hidden border-8 border-gray-100 rounded-2xl bg-white">

            <!-- ✅ Background image -->
            <img src="<?php echo e(asset('img/bg.png')); ?>"
                 style="position: absolute; inset: 0; width: 100%; height: 100%;
                        object-fit: cover; z-index: 0; border-radius: 0; margin: 0;">

            <!-- ✅ Overlay to fix edge bleed -->
            <div style="position:absolute; inset:0; background:white; opacity:0.03; z-index:1;"></div>

            <!-- ✅ Content -->
            <div class="relative z-10 flex flex-col justify-between h-full px-16 py-10 text-center">

                <!-- Header -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-700 tracking-widest uppercase">
                        Certificate of Achievement
                    </h2>
                    <p class="text-sm text-gray-500 font-medium mt-1 tracking-wide uppercase">
                        Proudly Presented To
                    </p>
                </div>

                <!-- Name -->
                <!-- Name -->
                <div>
                    <h1 class="text-5xl font-extrabold text-blue-900 tracking-wide cert-name uppercase drop-shadow-md">
                        <?php echo e(strtoupper($certificate->name)); ?>

                    </h1>

                    <div class="w-64 mx-auto border-t-2 border-gray-400 my-2"></div>

                    <div class="text-gray-700 mt-2 mx-auto text-lg italic drop-shadow-sm w-90-percent jp-text">
                        <?php echo $certificate->description; ?>

                    </div>

                    <h2 class="text-5xl font-bold text-red-700 mt-8 uppercase tracking-widest drop-shadow-lg">
                        <?php echo e(strtoupper($certificate->category->name)); ?>

                    </h2>
                </div>

                <!-- Issue date -->
                <div class="flex justify-center items-center gap-2 mt-6 text-gray-700 text-base">
                    <span class="font-semibold">Issued on:</span>
                    <?php
                        $date = DateTime::createFromFormat('Y-m-d', $certificate->reg_date);
                    ?>
                    <span class="border-b border-gray-500 px-2"><?php echo e($date->format('d')); ?></span> /
                    <span class="border-b border-gray-500 px-4"><?php echo e($date->format('F')); ?></span> /
                    <span class="border-b border-gray-500 px-2"><?php echo e($date->format('Y')); ?></span>
                </div>

                <!-- Footer -->
                <div class="relative top-[0px] bottom-part">
                    <div class="flex justify-between items-center">

                        <!-- Logo -->
                        <div class="flex flex-col items-center ml-6">
                            <img src="<?php echo e(asset('img/JDU-logo1.png')); ?>" alt="JDU Logo" class="w-44 h-auto">
                        </div>


                        <!-- Rector -->
                        <div class="text-center ml-2">
                            <p class="font-semibold text-lg">R. MAMAJONOV</p>
                            <p class="font-semibold text-sm text-gray-700">Rector of Japan Digital University</p>
                        </div>

                        <!-- Seal -->
                        <div class="mr-6 flex justify-end">
                            <img src="<?php echo e(asset('img/verified.png')); ?>" alt="Seal" class="w-40 h-auto object-contain">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH /Users/boburbek/Documents/projects/cert.local/resources/views/certificate/view.blade.php ENDPATH**/ ?>