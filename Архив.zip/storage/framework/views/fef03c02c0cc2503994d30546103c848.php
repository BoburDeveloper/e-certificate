<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($form_type == 'update' ? 'Edit Certificate' : 'Create Certificate').'']); ?>
    <div class="max-w-3xl mx-auto bg-white shadow-xl rounded-2xl overflow-hidden mt-10 border border-gray-100">
        
        <div class="bg-gradient-to-r from-indigo-600 to-blue-500 px-6 py-4">
            <h1 class="text-2xl font-bold text-white">
                <?php echo e($form_type == 'update' ? '✏️ Update Certificate' : '🎓 Create New Certificate'); ?>

            </h1>
        </div>

        <div class="p-8 space-y-6">
            
            <?php if($errors->any()): ?>
                <div class="bg-red-50 border-l-4 border-red-400 text-red-700 p-4 rounded-md shadow-sm">
                    <ul class="list-disc list-inside text-sm">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <form method="POST"
                  action="<?php echo e($form_type == 'update'
                        ? route('certificate.update', $certificate->id)
                        : route('certificate.store')); ?>"
                  enctype="multipart/form-data"
                  class="space-y-6">

                <?php echo csrf_field(); ?>
                <?php if($form_type == 'update'): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">Full Name</label>
                    <input type="text" name="name" required
                           value="<?php echo e(old('name', $certificate->name ?? '')); ?>"
                           class="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 p-2.5 shadow-sm">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">JDU ID</label>
                    <input type="text" name="jdu_id" required
                           value="<?php echo e(old('name', $certificate->jdu_id ?? '')); ?>"
                           class="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 p-2.5 shadow-sm">
                </div>

                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">Role</label>
                    <select name="role_id" required
                            class="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 p-2.5 shadow-sm bg-white">
                        <option value="">-- Select Role --</option>
                        <option value="1" <?php echo e(old('role_id', $certificate->role_id ?? '') == 1 ? 'selected' : ''); ?>>Talaba</option>
                        <option value="2" <?php echo e(old('role_id', $certificate->role_id ?? '') == 2 ? 'selected' : ''); ?>>O'qituvchi</option>
                    </select>
                </div>

                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">Category</label>
                    <select name="category_id" required
                            class="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 p-2.5 shadow-sm bg-white">
                        <option value="1" <?php echo e(old('category_id', $certificate->category_id ?? '') == 1 ? 'selected' : ''); ?>>
                            Student of the Month
                        </option>
                    </select>
                </div>

                <div>
                    <label for="reg_date" class="block text-sm font-medium text-gray-700 mb-1">
                        Registration Date
                    </label>
                    <input
                        type="date"
                        name="reg_date"
                        id="reg_date"
                        value="<?php echo e(old('reg_date', $certificate->reg_date ?? '')); ?>"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-gray-700
               focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-blue-400
               transition duration-200 ease-in-out bg-gray-50"
                        required
                    >
                </div>

                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">Description</label>
                    <textarea name="description" rows="4"
                              class="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 p-2.5 shadow-sm"
                              placeholder="Write about the student's achievement..."><?php echo e(old('description', $certificate->description ?? '')); ?></textarea>
                </div>

                
                <?php if($form_type == 'update'): ?>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">Status</label>
                        <select name="status" required
                                class="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 p-2.5 shadow-sm bg-white">
                            <option value="1" <?php echo e($certificate->status == 1 ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e($certificate->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                <?php endif; ?>

                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Photo</label>
                    <?php if(isset($certificate->photo)): ?>
                        <img src="<?php echo e(url('storage/'.$certificate->photo)); ?>"
                             class="w-28 h-28 object-cover rounded-lg border border-gray-200 mb-3 shadow-sm">
                    <?php endif; ?>
                    <input name="photo" type="file"
                           class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 transition-all">
                    <p class="text-xs text-gray-500 mt-1">Accepted formats: JPG, PNG. Max 2MB.</p>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Certificate</label>
                    <?php if(isset($certificate->file)): ?>
                        <a href="<?php echo e(url('storage/'.$certificate->file)); ?>">File</a>
                    <?php endif; ?>
                    <input name="file" type="file"
                           class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none file:mr-3 file:py-2 file:px-4 file:rounded-md file:border-0 file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 transition-all">
                    <p class="text-xs text-gray-500 mt-1">Accepted formats: PDF, JPG, PNG. Max 2MB.</p>
                </div>

                
                <div class="pt-4 flex items-center justify-end space-x-3">
                    <a href="<?php echo e(route('certificate.index')); ?>"
                       class="px-5 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-100 transition">
                        Cancel
                    </a>
                    <button type="submit"
                            class="px-6 py-2 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition shadow">
                        <?php echo e($form_type == 'update' ? 'Update' : 'Save'); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php /**PATH /Users/boburbek/Documents/projects/cert.local/resources/views/certificate/form.blade.php ENDPATH**/ ?>